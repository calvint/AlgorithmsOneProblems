from bitarray import bitarray

a = bitarray("01001001001011100110101")
b = bitarray("1011010100100101")
print b
print a
a += b
print a
